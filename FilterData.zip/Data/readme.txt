Data for Radiation Laws experiment at Imperial College London 3rd Year Underraduate Physics
Year: 2018
Authors: Artur Donaldson, James Mead

Aim: to determine Planck's constant by measuring the variaiton of intensity of a source with temperature

Quanities as described in lab book
I1	I1 err	V1	V1 err	R1	R1 err	R1/R293	R1/R293 err	Tres	Tres err	Trad	Trad err	VD average	VD err	ln(VD)	ln(VD) err	1/Trad	1/Trad err

Data exported from Origin Pro 2017
1st line = Name
2nd line = Units
Delimeter = Tab